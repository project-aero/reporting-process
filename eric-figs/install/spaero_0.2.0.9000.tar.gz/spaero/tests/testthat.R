library(testthat)
library(spaero)

test_check("spaero")
